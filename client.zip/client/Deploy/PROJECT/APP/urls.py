
from django.urls import path
from . import views

urlpatterns =[
    
    path('', views.Landing_1, name='Landing_1'),
    path('Register_2/', views.Register_2, name='Register_2'),
    path('Login_3/', views.Login_3, name='Login_3'),
    path('Home_4', views.Home_4, name='Home_4'),
    path('Deploy_7/', views.Deploy_7, name='Deploy_7'),
    path('Logout/', views.Logout, name='Logout'),
    path('domain/',views.domain,name='domain'),
]