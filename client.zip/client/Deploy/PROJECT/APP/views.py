from django.shortcuts import render, redirect
from .models import BitcoinPrediction, LitecoinPrediction, StellarPrediction
from APP.models import BitcoinPrediction, LitecoinPrediction, StellarPrediction
from . forms import  UserRegisterForm
from django.contrib.auth import authenticate, login,logout
from django.contrib import messages
import numpy as np
import joblib
import seaborn as sns
import matplotlib.pyplot as plt
import base64
from io import BytesIO
from django.utils import timezone
from IPython.display import display, Image


def Landing_1(request):
    return render(request, '1_Landing.html')

def Register_2(request):
    form = UserRegisterForm()
    if request.method =='POST':
        form = UserRegisterForm(request.POST)
        
        if form.is_valid():
            form.save()
            print('data passed')
            user = form.cleaned_data.get('username')
            print(user)
            messages.success(request, 'Account was successfully created. ' + user)
            return redirect('Login_3')

    context = {'form':form}
    return render(request, '2_Register.html', context)


def Login_3(request):
    if request.method =='POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(username=username, password=password)
        print(user)

        if user is not None:
            login(request, user)
            return redirect('Home_4')
        else:
            messages.info(request, 'Username OR Password incorrect')

    context = {}
    return render(request,'3_Login.html', context)

def Home_4(request):
    return render(request, '4_Home.html')

def Teamates_5(request):
    return render(request,'5_Teamates.html')

def Domain_Result_6(request):
    return render(request,'6_Domain_Result.html')



from django.shortcuts import render
from .forms import StockInputForm
import pandas as pd
import numpy as np
import joblib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
from .models import compute_rsi  # if it's in a separate utils/models file, else define here too
from .models import predict_next_days, compute_rsi, model, scaler
from django.shortcuts import render
from .forms import StockInputForm
import pandas as pd
import numpy as np
import joblib
from datetime import datetime, timedelta
import matplotlib.pyplot as plt

# Load trained model and scaler
model = joblib.load('APP/stock_rf_model.pkl')
scaler = joblib.load('APP/stock_scaler.pkl')

from django.shortcuts import render
from .forms import StockInputForm
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import joblib
from datetime import datetime, timedelta

from django.shortcuts import render
from .forms import StockInputForm
import joblib
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta

import pandas as pd
from django.shortcuts import render
from statsmodels.tsa.statespace.sarimax import SARIMAX
from statsmodels.tsa.arima.model import ARIMA
import matplotlib.pyplot as plt
from io import BytesIO
import base64
from datetime import datetime
import warnings
warnings.filterwarnings("ignore")

def Deploy_7(request):
    context = {}
    if request.method == 'POST':
        product_id = request.POST.get('product_id')
        product_name = request.POST.get('product_name')
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')

        df = pd.read_csv('APP/product_sales.csv')
        df['Date'] = pd.to_datetime(df['Date'], errors='coerce', dayfirst=True)

        product_df = df[df['Product_ID'] == product_id]
        product_df.set_index('Date', inplace=True)
        product_df = product_df.resample('D').sum()

        if len(product_df) < 5:
            context['error'] = "Not enough data for forecasting. Add more data points."
        else:
            model_arima = ARIMA(product_df['Sales'], order=(1, 1, 1))
            model_arima_fit = model_arima.fit()

            model_sarima = SARIMAX(product_df['Sales'], order=(1, 1, 1), seasonal_order=(1, 1, 1, 7))
            model_sarima_fit = model_sarima.fit(disp=False)

            start_date_dt = pd.to_datetime(start_date)
            end_date_dt = pd.to_datetime(end_date)

            if end_date_dt <= start_date_dt:
                context['error'] = "End date must be after start date."
            elif start_date_dt <= product_df.index.max():
                context['error'] = f"Forecast should start after {product_df.index.max().date()}"
            else:
                forecast_arima = model_arima_fit.predict(start=start_date_dt, end=end_date_dt, typ='levels')
                forecast_sarima = model_sarima_fit.predict(start=start_date_dt, end=end_date_dt)

                # 📌 Combine into list of dicts for dashboard table
                combined_forecast = []
                for date in forecast_arima.index:
                    combined_forecast.append({
                        'date': date.strftime('%Y-%m-%d'),
                        'arima': round(forecast_arima[date], 2),
                        'sarima': round(forecast_sarima[date], 2)
                    })

                # 📊 Plot
                plt.figure(figsize=(12, 5))
                plt.plot(product_df['Sales'], label='Actual Sales')
                plt.plot(forecast_arima, label='ARIMA Forecast', color='red')
                plt.plot(forecast_sarima, label='SARIMA Forecast', color='green')
                plt.title(f'Sales Forecast for {product_id} ({product_name})')
                plt.xlabel('Date')
                plt.ylabel('Sales')
                plt.legend()
                plt.grid()

                buffer = BytesIO()
                plt.savefig(buffer, format='png')
                buffer.seek(0)
                image_png = buffer.getvalue()
                buffer.close()
                graph = base64.b64encode(image_png).decode('utf-8')

                                # 📊 Second graph: Forecasted values comparison graph
                plt.figure(figsize=(10, 5))
                plt.plot(forecast_arima.index, forecast_arima.values, label='ARIMA Forecast', marker='o', color='red')
                plt.plot(forecast_sarima.index, forecast_sarima.values, label='SARIMA Forecast', marker='o', color='green')
                plt.title(f'Forecasted Sales Values Comparison for {product_id} ({product_name})')
                plt.xlabel('Date')
                plt.ylabel('Forecasted Sales')
                plt.legend()
                plt.grid()

                # Save second graph to base64
                buffer2 = BytesIO()
                plt.savefig(buffer2, format='png')
                buffer2.seek(0)
                image_png2 = buffer2.getvalue()
                buffer2.close()
                graph2 = base64.b64encode(image_png2).decode('utf-8')

                # Pass second graph to context
                context['graph2'] = graph2


                context.update({
                    'graph': graph,
                    'product_id': product_id,
                    'product_name': product_name,
                    'combined_forecast': combined_forecast,  # <- Pass it to template
                })

    return render(request, 'input.html', context)



def Logout(request):
    
    logout(request)
    return redirect('Landing_1')

def domain(request):
    return render(request,'domain.html')

