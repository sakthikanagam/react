from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone




class BitcoinPrediction(models.Model):
    open_price = models.FloatField()
    high_price = models.FloatField()
    low_price = models.FloatField()
    volume = models.IntegerField()
    closing_price = models.FloatField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Prediction: {self.closing_price}"
    
class LitecoinPrediction(models.Model):
    open_price = models.FloatField()
    high_price = models.FloatField()
    low_price = models.FloatField()
    volume = models.IntegerField()
    closing_price = models.FloatField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Prediction: {self.closing_price}"
    
class StellarPrediction(models.Model):
    open_price = models.FloatField()
    high_price = models.FloatField()
    low_price = models.FloatField()
    volume = models.IntegerField()
    closing_price = models.FloatField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Prediction: {self.closing_price}"
    
import pandas as pd
import numpy as np
import joblib
import os

# Load pre-trained Random Forest model and scaler
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
model_path = os.path.join(BASE_DIR, 'stock_rf_model.pkl')
scaler_path = os.path.join(BASE_DIR, 'stock_scaler.pkl')

model = joblib.load(model_path)
scaler = joblib.load(scaler_path)

# RSI calculation function
def compute_rsi(series, window=14):
    delta = series.diff()
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)

    avg_gain = gain.rolling(window=window, min_periods=1).mean()
    avg_loss = loss.rolling(window=window, min_periods=1).mean()

    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

# Function to make predictions on new data
def predict_next_days(last_known_data, new_data, features):
    # No imports inside the function — variables and functions are already in scope

    # Combine historical and new data
    combined = pd.concat([last_known_data, new_data])

    # Calculate indicators
    combined['Daily_Return'] = combined['Close'].pct_change()
    combined['SMA_5'] = combined['Close'].rolling(window=5, min_periods=1).mean()
    combined['SMA_20'] = combined['Close'].rolling(window=20, min_periods=1).mean()
    combined['EMA_12'] = combined['Close'].ewm(span=12, adjust=False, min_periods=1).mean()
    combined['EMA_26'] = combined['Close'].ewm(span=26, adjust=False, min_periods=1).mean()
    combined['MACD'] = combined['EMA_12'] - combined['EMA_26']
    combined['RSI'] = compute_rsi(combined['Close'])

    # Get only new data with features
    new_with_features = combined.loc[new_data.index]
    new_with_features = new_with_features[features].dropna()

    if len(new_with_features) == 0:
        raise ValueError("No valid data after feature engineering")

    # Scale and predict
    scaled_data = scaler.transform(new_with_features)
    predictions = model.predict(scaled_data)
    probabilities = model.predict_proba(scaled_data)

    # Prepare results
    results = new_with_features.copy()
    results['Prediction'] = predictions
    results['Probability_Up'] = probabilities[:, 1]
    results['Predicted_Label'] = np.where(results['Prediction'] == 1, 'Up', 'Down')

    return results[['Close', 'Predicted_Label', 'Probability_Up']]

     