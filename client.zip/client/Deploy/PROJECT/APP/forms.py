from django import forms 


from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User



class UserRegisterForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']
        
from django import forms

class StockInputForm(forms.Form):
    open_price = forms.FloatField(label='Open Price')
    high_price = forms.FloatField(label='High Price')
    low_price = forms.FloatField(label='Low Price')
    close_price = forms.FloatField(label='Close Price')
    adj_close_price = forms.FloatField(label='Adjusted Close Price')
    volume = forms.IntegerField(label='Volume')

        
        
        
